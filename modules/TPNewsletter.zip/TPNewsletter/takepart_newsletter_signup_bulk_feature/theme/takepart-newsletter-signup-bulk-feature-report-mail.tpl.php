Report Ready at <?php print url("node/".$node->nid , array("absolute"=>TRUE)) ?>.

