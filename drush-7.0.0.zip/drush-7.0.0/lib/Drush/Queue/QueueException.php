<?php

namespace Drush\Queue;

class QueueException extends \Exception {}
